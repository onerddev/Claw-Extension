/* CLAW — background.js v19.1 | Emanuel Felipe
   · Proxy Groq API (com tratamento de erros 401/429/503)
   · Modelos atualizados: llama-3.3-70b-versatile (produção)
   · Commander: abre sites, pesquisa, controla abas
   · Re-injeta scripts em novas abas
*/
'use strict';

const KEY = '''';

/* ── SITES CONHECIDOS ───────────────────────────────────────── */
const SITES = {
  // Redes sociais
  'youtube':        'https://youtube.com',
  'instagram':      'https://instagram.com',
  'twitter':        'https://twitter.com',
  'x':              'https://x.com',
  'tiktok':         'https://tiktok.com',
  'facebook':       'https://facebook.com',
  'whatsapp':       'https://web.whatsapp.com',
  'telegram':       'https://web.telegram.org',
  'discord':        'https://discord.com/app',
  'reddit':         'https://reddit.com',
  'linkedin':       'https://linkedin.com',
  'twitch':         'https://twitch.tv',
  'pinterest':      'https://pinterest.com',
  'snapchat':       'https://snapchat.com',
  'threads':        'https://threads.net',
  'bluesky':        'https://bsky.app',
  // Google
  'gmail':          'https://mail.google.com',
  'drive':          'https://drive.google.com',
  'google drive':   'https://drive.google.com',
  'docs':           'https://docs.google.com',
  'google docs':    'https://docs.google.com',
  'sheets':         'https://sheets.google.com',
  'slides':         'https://slides.google.com',
  'forms':          'https://forms.google.com',
  'meet':           'https://meet.google.com',
  'classroom':      'https://classroom.google.com',
  'maps':           'https://maps.google.com',
  'google maps':    'https://maps.google.com',
  'calendar':       'https://calendar.google.com',
  'fotos':          'https://photos.google.com',
  'translate':      'https://translate.google.com',
  'tradutor':       'https://translate.google.com',
  'keep':           'https://keep.google.com',
  // Produtividade
  'notion':         'https://notion.so',
  'trello':         'https://trello.com',
  'asana':          'https://asana.com',
  'github':         'https://github.com',
  'gitlab':         'https://gitlab.com',
  'figma':          'https://figma.com',
  'canva':          'https://canva.com',
  'miro':           'https://miro.com',
  'slack':          'https://slack.com',
  'zoom':           'https://zoom.us',
  'outlook':        'https://outlook.live.com',
  'onedrive':       'https://onedrive.live.com',
  'office':         'https://office.com',
  'teams':          'https://teams.microsoft.com',
  'dropbox':        'https://dropbox.com',
  'linear':         'https://linear.app',
  // Entretenimento
  'netflix':        'https://netflix.com',
  'prime':          'https://primevideo.com',
  'amazon prime':   'https://primevideo.com',
  'disney':         'https://disneyplus.com',
  'disney+':        'https://disneyplus.com',
  'hbo':            'https://max.com',
  'max':            'https://max.com',
  'star+':          'https://starplus.com',
  'globoplay':      'https://globoplay.globo.com',
  'crunchyroll':    'https://crunchyroll.com',
  'anime':          'https://crunchyroll.com',
  'spotify':        'https://open.spotify.com',
  'deezer':         'https://deezer.com',
  'soundcloud':     'https://soundcloud.com',
  'apple music':    'https://music.apple.com',
  'twitch tv':      'https://twitch.tv',
  'kick':           'https://kick.com',
  // Notícias
  'g1':             'https://g1.globo.com',
  'uol':            'https://uol.com.br',
  'terra':          'https://terra.com.br',
  'r7':             'https://r7.com',
  'bbc':            'https://bbc.com/portuguese',
  'cnn':            'https://cnn.com',
  // Estudo
  'kahoot':         'https://kahoot.it',
  'stopots':        'https://stopots.com',
  'duolingo':       'https://duolingo.com',
  'brainly':        'https://brainly.com.br',
  'wikipedia':      'https://pt.wikipedia.org',
  'khanacademy':    'https://khanacademy.org',
  'coursera':       'https://coursera.org',
  'udemy':          'https://udemy.com',
  // IA
  'chatgpt':        'https://chatgpt.com',
  'claude':         'https://claude.ai',
  'gemini':         'https://gemini.google.com',
  'copilot':        'https://copilot.microsoft.com',
  'perplexity':     'https://perplexity.ai',
  'midjourney':     'https://midjourney.com',
  // Compras
  'amazon':         'https://amazon.com.br',
  'mercado livre':  'https://mercadolivre.com.br',
  'ml':             'https://mercadolivre.com.br',
  'shopee':         'https://shopee.com.br',
  'magalu':         'https://magazineluiza.com.br',
  'magazine luiza': 'https://magazineluiza.com.br',
  'americanas':     'https://americanas.com.br',
  'aliexpress':     'https://aliexpress.com',
  'shein':          'https://shein.com.br',
  'casas bahia':    'https://casasbahia.com.br',
  // Delivery / Serviços
  'ifood':          'https://ifood.com.br',
  'rappi':          'https://rappi.com.br',
  '99':             'https://99app.com',
  'uber':           'https://uber.com',
  'airbnb':         'https://airbnb.com.br',
  'booking':        'https://booking.com',
  // Outros
  'google':         'https://google.com',
  'bing':           'https://bing.com',
  'duckduckgo':     'https://duckduckgo.com',
  'icloud':         'https://icloud.com',
  'nubank':         'https://nubank.com.br',
  'inter':          'https://inter.co',
  'itau':           'https://itau.com.br',
  'bradesco':       'https://bradesco.com.br',
};

/* ── MOTORES DE BUSCA ───────────────────────────────────────── */
const SEARCH = {
  'youtube':        q => `https://youtube.com/results?search_query=${E(q)}`,
  'google':         q => `https://google.com/search?q=${E(q)}`,
  'bing':           q => `https://bing.com/search?q=${E(q)}`,
  'duckduckgo':     q => `https://duckduckgo.com/?q=${E(q)}`,
  'maps':           q => `https://maps.google.com/search?q=${E(q)}`,
  'google maps':    q => `https://maps.google.com/search?q=${E(q)}`,
  'wikipedia':      q => `https://pt.wikipedia.org/wiki/Special:Search?search=${E(q)}`,
  'twitter':        q => `https://twitter.com/search?q=${E(q)}`,
  'reddit':         q => `https://reddit.com/search?q=${E(q)}`,
  'amazon':         q => `https://amazon.com.br/s?k=${E(q)}`,
  'shopee':         q => `https://shopee.com.br/search?keyword=${E(q)}`,
  'mercado livre':  q => `https://lista.mercadolivre.com.br/${E(q)}`,
  'ml':             q => `https://lista.mercadolivre.com.br/${E(q)}`,
  'magalu':         q => `https://www.magazineluiza.com.br/busca/${E(q)}`,
  'github':         q => `https://github.com/search?q=${E(q)}`,
  'steam':          q => `https://store.steampowered.com/search/?term=${E(q)}`,
};

const E = encodeURIComponent;

/* ── PARSER ─────────────────────────────────────────────────── */
function parseAndRun(rawText, sendResponse) {
  const raw  = rawText.trim();
  const low  = raw.toLowerCase();

  const open = (urls, label) => {
    urls.forEach((url, i) => chrome.tabs.create({ url, active: i === 0 }));
    const msg = urls.length === 1
      ? `✓ Abrindo ${label || urls[0]}`
      : `✓ Abrindo ${urls.length} abas!`;
    sendResponse({ ok: true, msg });
  };

  /* ── 1. PESQUISA EM SITE ESPECÍFICO ── */
  // "pesquisa minecraft no youtube"
  // "busca tênis na shopee"
  const inRx = /^(?:pesquisa|busca|procura|search|procure)\s+(.+?)\s+n[ao]\s+(.+)/i;
  const inM  = raw.match(inRx);
  if (inM) {
    const q = inM[1].trim(), site = inM[2].trim().toLowerCase();
    const fn = SEARCH[site];
    if (fn) { open([fn(q)], `"${q}" no ${site}`); return; }
  }

  /* ── 2. YOUTUBE DIRETO ── */
  // "youtube lofi" / "coloca lofi no youtube" / "pesquisa lofi no youtube"
  const ytRx = /^(?:coloca|toca|play|youtube|pesquisa.*no youtube)\s+(.+?)(?:\s+no youtube)?$/i;
  const ytM  = raw.match(ytRx);
  if (ytM || low.startsWith('youtube ')) {
    const q = ytM ? ytM[1] : raw.slice(8);
    open([SEARCH.youtube(q.trim())], `"${q.trim()}" no YouTube`);
    return;
  }

  /* ── 3. PESQUISA GERAL ── */
  // "pesquisa como fazer bolo" / "googla receita"
  const srRx = /^(?:pesquisa|busca|procura|googla|search|pesquisar|google)\s+(.+)/i;
  const srM  = raw.match(srRx);
  if (srM) { open([SEARCH.google(srM[1].trim())], `"${srM[1].trim()}"`); return; }

  /* ── 4. ABRIR MÚLTIPLOS ── */
  // "abre youtube e gmail" / "abre netflix, spotify e discord"
  const opRx = /^(?:abr[ae]r?|vai|acessa|entra|ir para|vai para|navega para|abre)\s+(.+)/i;
  const opM  = raw.match(opRx);
  if (opM) {
    const parts = opM[1]
      .split(/\s+e\s+|\s*,\s*/i)
      .map(s => s.trim().toLowerCase())
      .filter(Boolean);
    const urls = parts.map(p => SITES[p]).filter(Boolean);
    if (urls.length > 0) { open(urls); return; }
    // tenta como nome direto de site
    const single = SITES[opM[1].trim().toLowerCase()];
    if (single) { open([single]); return; }
  }

  /* ── 5. SITE DIRETO ── */
  const direct = SITES[low];
  if (direct) { open([direct]); return; }

  /* ── 6. URL DIRETA ── */
  if (/^https?:\/\//i.test(raw)) { open([raw]); return; }
  if (/^www\./i.test(raw)) { open([`https://${raw}`]); return; }
  if (/\.(com|net|org|io|app|br|tv)(\/?|$)/i.test(raw) && !raw.includes(' ')) {
    open([`https://${raw}`]); return;
  }

  /* ── 7. CONTROLE DE ABAS ── */
  if (/fecha(r)?\s*(essa|a|esta|a)?\s*aba/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true}, ([t]) => {
      if (t) chrome.tabs.remove(t.id);
      sendResponse({ok:true, msg:'✓ Aba fechada!'});
    });
    return;
  }
  if (/nova aba|aba nova|abre uma aba/i.test(raw)) {
    chrome.tabs.create({url:'chrome://newtab/'});
    sendResponse({ok:true, msg:'✓ Nova aba!'});
    return;
  }
  if (/^volta(r)?$/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.scripting.executeScript({target:{tabId:t.id},func:()=>history.back()});
      sendResponse({ok:true,msg:'✓ Voltando...'});
    });
    return;
  }
  if (/^avan[çc]a(r)?|^frente$/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.scripting.executeScript({target:{tabId:t.id},func:()=>history.forward()});
      sendResponse({ok:true,msg:'✓ Avançando...'});
    });
    return;
  }
  if (/recarrega(r)?|atualiza(r)?|refresh|f5/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.tabs.reload(t.id);
      sendResponse({ok:true,msg:'✓ Recarregado!'});
    });
    return;
  }
  if (/rola.*baixo|scroll down|desce/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.scripting.executeScript({target:{tabId:t.id},func:()=>window.scrollBy({top:500,behavior:'smooth'})});
      sendResponse({ok:true,msg:'✓ Rolando...'});
    });
    return;
  }
  if (/rola.*cima|scroll up|sobe|topo/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.scripting.executeScript({target:{tabId:t.id},func:()=>window.scrollTo({top:0,behavior:'smooth'})});
      sendResponse({ok:true,msg:'✓ No topo!'});
    });
    return;
  }
  if (/duplica(r)?\s*aba|clona(r)?\s*aba/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.tabs.create({url:t.url});
      sendResponse({ok:true,msg:'✓ Aba duplicada!'});
    });
    return;
  }
  if (/fixa(r)?\s*aba|pin/i.test(raw)) {
    chrome.tabs.query({active:true,currentWindow:true},([t])=>{
      chrome.tabs.update(t.id,{pinned:!t.pinned});
      sendResponse({ok:true,msg:t.pinned?'✓ Aba desafixada!':'✓ Aba fixada!'});
    });
    return;
  }
  if (/muda.*aba|pr[oó]xima aba|aba (direita|seguinte)/i.test(raw)) {
    chrome.tabs.query({currentWindow:true},tabs=>{
      chrome.tabs.query({active:true,currentWindow:true},([t])=>{
        const idx=tabs.findIndex(x=>x.id===t.id);
        const next=tabs[(idx+1)%tabs.length];
        chrome.tabs.update(next.id,{active:true});
        sendResponse({ok:true,msg:'✓ Próxima aba!'});
      });
    });
    return;
  }
  if (/aba (esquerda|anterior)/i.test(raw)) {
    chrome.tabs.query({currentWindow:true},tabs=>{
      chrome.tabs.query({active:true,currentWindow:true},([t])=>{
        const idx=tabs.findIndex(x=>x.id===t.id);
        const prev=tabs[(idx-1+tabs.length)%tabs.length];
        chrome.tabs.update(prev.id,{active:true});
        sendResponse({ok:true,msg:'✓ Aba anterior!'});
      });
    });
    return;
  }
  if (/quantas abas/i.test(raw)) {
    chrome.tabs.query({currentWindow:true},tabs=>{
      sendResponse({ok:true,msg:`✓ Você tem ${tabs.length} aba${tabs.length!==1?'s':''} abertas.`});
    });
    return;
  }

  /* ── 8. FALLBACK ── */
  if (raw.length > 1) {
    open([SEARCH.google(raw)], `"${raw}"`);
  } else {
    sendResponse({ok:false, msg:'Não entendi. Tente: "abre youtube" ou "pesquisa receita de bolo"'});
  }
}

/* ── LISTENERS ──────────────────────────────────────────────── */
chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg.type === 'PING') { reply({ok:true}); return false; }

  /* Proxy Groq */
  if (msg.type === 'GROQ_FETCH') {
    fetch('https://api.groq.com/openai/v1/chat/completions', {
      method : 'POST',
      headers: {'Content-Type':'application/json','Authorization':`Bearer ${msg.key||KEY}`},
      body   : JSON.stringify(msg.payload),
    })
    .then(async res => {
      const data = await res.json();
      if (!res.ok) {
        let errMsg = data?.error?.message || `HTTP ${res.status}`;
        if (res.status === 429) errMsg = '⏳ Limite de requisições atingido. Aguarde alguns segundos e tente de novo.';
        if (res.status === 401) errMsg = '🔑 Chave de API inválida ou expirada.';
        if (res.status === 503) errMsg = '🔧 Serviço temporariamente indisponível. Tente novamente.';
        reply({ok:false, error:errMsg});
      } else {
        reply({ok:true, data});
      }
    })
    .catch(err => reply({ok:false, error:'❌ Sem conexão com a API: ' + err.message}));
    return true;
  }

  /* Commander */
  if (msg.type === 'CMD_RUN') {
    parseAndRun(msg.text || '', reply);
    return true;
  }
});

/* ── RE-INJETA SCRIPTS ──────────────────────────────────────── */
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== 'complete') return;
  if (!tab.url || tab.url.startsWith('chrome') || tab.url.startsWith('about')) return;

  chrome.storage.sync.get(['tr_on','tr_lang','summarize_on','explain_on','anti_on'], d => {
    const inj = (files, m) => {
      chrome.scripting.executeScript({target:{tabId}, files}, () => {
        if (chrome.runtime.lastError) return;
        chrome.tabs.sendMessage(tabId, m, () => void chrome.runtime.lastError);
      });
    };
    if (d.tr_on)                       inj(['translator.js'],  {type:'TR_ON',    lang:d.tr_lang||'auto'});
    if (d.summarize_on||d.explain_on)  inj(['page_tools.js'],  {type:'TOOLS_ON', summarize:d.summarize_on, explain:d.explain_on});
    if (d.anti_on)                     inj(['anti_detect.js'], {type:'ANTI_ON'});
  });
});

chrome.runtime.onInstalled.addListener(() => console.log('[Claw] v19 instalado.'));
