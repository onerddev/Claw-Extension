# 🦞 Claw — Agente IA para Chrome

Extensão Chrome com IA integrada que controla o navegador, responde perguntas, joga Kahoot/StopotS automaticamente e muito mais.

## ⚙️ Configuração

1. Obtenha sua chave API gratuita em [console.groq.com](https://console.groq.com)
2. Abra os seguintes arquivos e substitua `SUA_CHAVE_API_GROQ_AQUI` pela sua chave:
   - `background.js`
   - `popup.js`
   - `kahoot.js`
   - `stopots.js`
   - `page_tools.js`
   - `translator.js`
   - `study_mode.js`
   - `plugins/youtube.js`
   - `plugins/gmail.js`
   - `plugins/whatsapp.js`
   - `plugins/google_docs.js`

## 📦 Instalação

1. Baixe ou clone este repositório
2. Configure sua chave API (passo acima)
3. Abra `chrome://extensions` no Chrome
4. Ative o **Modo desenvolvedor** (canto superior direito)
5. Clique em **Carregar sem compactação** e selecione a pasta do projeto

## 🚀 Funcionalidades

- **Chat IA flutuante** — acessível em qualquer site, arrastável
- **Agente IA** — controla o Chrome: clica, digita, navega, extrai dados
- **Kahoot** — responde automaticamente com IA
- **StopotS** — respostas automáticas com cache
- **Resumir páginas** — resume qualquer site
- **Tradutor** — tradução integrada
- **Modo Estudo** — resumos e palavras-chave
- **Plugins** — YouTube, Gmail, WhatsApp, Google Docs
- **Comando por voz** — controle por fala
- **Anti-detecção** — comportamento humano

## 👨‍💻 Desenvolvido por

**Emanuel Felipe**
